%% Initialize

close all
clearvars
clc

savedata = 0; % Set to 1 to save data

%% OMP

N = 100;

M_max = N;
s_max = N;
interval = 2; % Use 1 for N=20,50; use 2 for N=100

MC_runs = 1000; % Use 2000 for N=20,50; use 1000 for N=100

ESR = zeros(M_max,s_max); % Exact Support Recovery
ANE = zeros(M_max,s_max); % Average Normalized Error

tol = 1e-3; % Required error to successfully estimate x

for M = interval:interval:M_max

    sprintf('M=%d, dt=%d',M,toc)
    tic

    for s = interval:interval:s_max

        % sprintf('M=%d, s=%d',M,s)
    
        total_exact = zeros(MC_runs,1); % Total number of exact support recoveries
    
        NE = zeros(MC_runs,1); % Normalized error
    
        % Monte Carlo loop
        for i_MC = 1:MC_runs
    
            % sprintf('M=%d, MC=%d',M,i_MC)
    
            A = normc(normrnd(0,1,[M,N]));
    
            ones_zeros = [ones(s,1);zeros(s_max-s,1)];
            ones_zeros_R = ones_zeros(randperm(size(ones_zeros,1)),:); % Randomize ones_zeros's rows
            x = ones_zeros_R.*(1+9*rand(N,1)).*(-1).^(randi(2,N,1)); % Assign values to x
            
            n = zeros(size(A*x)); % Noise
            
            y = A*x+n;
            
            r = y; % Trivial residual
            xh = zeros(size(x)); % Trivial estimation
            err = sqrt(sum(r.^2)); % Trivial error
    
            LAMBDA = zeros([1,s]); % list of selected atoms

            k = 0;
    
            while err>tol

                k = k + 1;

                % Make atom selection
                [~,LAMBDA(k)] = max(abs(r'*A),[],2);
    
                % Least squares (to find new estimation)
                xh(LAMBDA(1:k)) = A(:,LAMBDA(1:k))\y; % Perform least squares on span(atoms) and y
    
                r = y - A*xh; % Calculate new residual
    
                err = sqrt(sum(r.^2,1));
    
            end % End of OMP loop
            total_exact(i_MC) = (err<=tol && k==s);
            NE(i_MC) = sqrt(sum((x-xh).^2))./sqrt(sum(x.^2));
        
        end % End of Monte Carlo sample
    
        ESR(M,s) = sum(total_exact)/MC_runs;
        ANE(M,s) = sum(NE)/MC_runs;

    end % End of s's

end % End of m's

%% Plot

ESRFig = figure;
ESRax = axes(ESRFig);
imagesc(ESRax,interval:interval:M_max,interval:interval:s_max,ESR(interval:interval:end,interval:interval:end))
set(ESRax,'YDir','normal')
colorbar(ESRax)
xlabel(ESRax,'s')
ylabel(ESRax,'M')
title(ESRax,sprintf('Exact Support Recovery (Noiseless)'))
subtitle(ESRax,sprintf('%d Monte Carlo runs (N = %d)',MC_runs,N))

ANEFig = figure;
ANEax = axes(ANEFig);
imagesc(ANEax,interval:interval:M_max,interval:interval:s_max,ANE(interval:interval:end,interval:interval:end))
set(ANEax,'YDir','normal')
colorbar(ANEax)
xlabel(ANEax,'s')
ylabel(ANEax,'M')
title(ANEax,sprintf('Average Normalized Error (Noiseless)'))
subtitle(ANEax,sprintf('%d Monte Carlo runs (N = %d)',MC_runs,N))

%% Save

if savedata
    save(sprintf('../Data/ECE269MP1Q3N%d',N))
    saveas(ESRFig, sprintf('../Figures/ESR_MC%d_N%d_noiseless.png',MC_runs,N))
    saveas(ANEFig, sprintf('../Figures/ANE_MC%d_N%d_noiseless.png',MC_runs,N))
end