%% Initialize

close all
clearvars
clc

savedata = 0; % set to 1 to save data

load ../Files/'Data for HW3'/'Y1 Y2 Y3 and A1 A2 A3.mat'

%% Data

s_max = size(A1, 2); % s_max = number of columns of A1
y = {y1 y2 y3};
A = {A1 A2 A3};
x = zeros(s_max,3);
x_lsqr = zeros(s_max,3);

OMP_loops_required = zeros(1,3); % number of OMP loops required to meet goal

%% OMP

for idx = 1:3

    r = y{idx}; % Trivial residual
    err = sqrt(sum(r.^2)); % Trivial error
    
    goal = 1e-9; % Determines when to terminate OMP loop
    
    LAMBDA = zeros([1,s_max]); % list of selected atoms
    
    k = 0;
    
    while (err>goal && k < s_max)
    
        k = k + 1;
    
        % Make atom selection
        [~,LAMBDA(k)] = max(abs(r'*A{idx}),[],2);
    
        % Least squares (to find new estimation)
        x(LAMBDA(1:k),idx) = A{idx}(:,LAMBDA(1:k))\y{idx}; % Perform least squares on span(atoms) and y
    
        r = y{idx} - A{idx}*x(:,idx); % Calculate new residual
        err = sqrt(sum(r.^2)); % Calculate new error

        sprintf('Image %d: k = %d: err = %.4d', idx, k, err)
    
    end % End of OMP loop

    OMP_loops_required(idx) = k;

end % End of all three iterations

%% LSQR

for idx = 1:3
    [x_lsqr(:,idx),~] = lsqr(A{idx},y{idx});
end

%% Generate Figures

for idx = 1:3 % OMP
    fig = figure;
    imagesc(reshape(x(:,idx),90,160))
    title(gca, sprintf('X (from Y%d = A%dX)',idx,idx))
    subtitle(gca,sprintf('%d OMP loops required to meet tolerance of %1.0d', OMP_loops_required(idx), goal))
    if savedata
        saveas(fig, sprintf('../Figures/IMG_A%d.png',idx))
    end
end

for idx = 1:3 % lsqr
    fig = figure;
    imagesc(reshape(x_lsqr(:,idx),90,160))
    title(gca, sprintf('X (from Y%d = A%dX)',idx,idx))
    subtitle(gca,sprintf('Using lsqr'))
    if savedata
        saveas(fig, sprintf('../Figures/IMG_A%d_LSQR.png',idx))
    end
end

%% Save Data and Plots

if savedata
    save(sprintf('../Data/ECE269MP1Q5'))
end