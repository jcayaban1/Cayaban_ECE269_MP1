%% Initialize

close all
clearvars
clc

savedata = 1; % set to 1 to save data

addpath('../Files/data/')
[y,D,A] = loading_data('../Files/data/');

%% Data

fps = 7350;
% sound(y,fps)

K = [10 50 100 200 300 1000 2000 3000];
% K = [20 21 22 23 24 25]; % Used for finding exact k where message is clear

sparsity = 100; % of s

s = zeros(size(D,2), length(K));
s_lsqr = zeros(size(D,2), length(K));
x = zeros(size(A,2), length(K));

%% OMP

for idx = 1:length(K)

    k = K(idx);
    yk = y(1:k);
    Ak = A(1:k,:);
    AkD = Ak*D;

    r = yk; % Trivial residual
    err = sqrt(sum(r.^2)); % Trivial error
    
    LAMBDA = zeros([1,sparsity]); % list of selected atoms
    
    for s_idx = 1:sparsity
    
        % Make atom selection
        [~,LAMBDA(s_idx)] = max(abs(r'*AkD),[],2);
    
        % Least squares (to find new estimation)
        s(LAMBDA(1:s_idx),idx) = AkD(:,LAMBDA(1:s_idx))\yk; % Perform least squares on span(atoms) and y
    
        r = yk - AkD*s(:,idx); % Calculate new residual
        err = sqrt(sum(r.^2)); % Calculate new error

        sprintf('k = %d: s_idx = %d', K(idx), s_idx)
    
    end % End of OMP loop

end % End of iterations for each k in K

%% LSQR

for idx = 1:length(K)
    sprintf('k = %d', K(idx))
    k = K(idx);
    yk = y(1:k);
    Ak = A(1:k,:);
    AkD = Ak*D;
    [s_lsqr(:,idx),~] = lsqr(AkD,yk);
end

%% Play Sound

for idx = 1:length(K)
    sound(D*s(:,idx),fps)
    sprintf('Playing sound for K = %d (OMP)',K(idx))
    pause(3)
end

for idx = 1:length(K)
    sound(D*s_lsqr(:,idx),fps)
    sprintf('Playing sound for K = %d (lsqr)',K(idx))
    pause(3)
end

%% Save Data and Plots

if savedata
    save(sprintf('../Data/ECE269MP1Q6'))
end